=== Plugin Name ===

Contributors: Domm Holland
Plugin Name: Byepass
Plugin URI: https://byepass.co/
Tags: wp, login, byepass, remove passwords
Author URI: https://byepass.co/
Author: Byepass
Requires at least: 2.3
Tested up to: 4.9
Stable tag: 1.0
Version: 1.0 

== Description ==

Byepass enables you to login to Wordpress without passwords.  Byepass is an authentication platform that is more secure than passwords and less annoying.